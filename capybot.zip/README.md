# Capybot 🦫

Capybot is a simple Discord bot with interactive counters!

## Features
- Create counters with `!? countername [startvalue]`
- Increase/Decrease counters with buttons (+1, +5, etc.)
- Reset, undo, and mark counters as finished
- Persistent storage between bot restarts

## Setup
1. Install dependencies:
   ```bash
   pip install discord.py
   ```

2. Set your bot token in an environment variable:
   ```bash
   export DISCORD_BOT_TOKEN=your_token_here
   ```

3. Run the bot:
   ```bash
   python capybot.py
   ```
