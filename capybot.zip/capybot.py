import discord
from discord.ext import commands
import os
import json

# Get token from environment variables for security
TOKEN = os.getenv("DISCORD_BOT_TOKEN")

# Intents
intents = discord.Intents.default()
intents.message_content = True

# Prefix bot ("!? " with space)
bot = commands.Bot(command_prefix="!?", intents=intents)

# Dictionary to store counters
counters = {}
COUNTERS_FILE = "counters_data.json"

# Store the permanent capybara image URLs
capybara_image_url = None
capybara_finished_url = None

# -------------------------------
# Persistence Functions
def save_counters():
    """Save counters to JSON file"""
    try:
        serializable_counters = {str(k): v for k, v in counters.items()}
        with open(COUNTERS_FILE, 'w') as f:
            json.dump(serializable_counters, f, indent=2)
    except Exception:
        pass

def load_counters():
    """Load counters from JSON file"""
    global counters
    try:
        if os.path.exists(COUNTERS_FILE):
            with open(COUNTERS_FILE, 'r') as f:
                data = json.load(f)
            counters = {int(k): v for k, v in data.items()}
        else:
            counters = {}
    except Exception:
        counters = {}

# -------------------------------
# Counter Buttons
class CounterView(discord.ui.View):
    def __init__(self, message_id: int, name: str, creator_id: int):
        super().__init__(timeout=None)
        self.message_id = message_id
        self.name = name
        self.creator_id = creator_id

    # Row 1: +1, +5, +10
    @discord.ui.button(label="▶️ Increase +1", style=discord.ButtonStyle.success, row=0)
    async def increase_one(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.modify_counter(interaction, 1)

    @discord.ui.button(label="⏩ Increase +5", style=discord.ButtonStyle.success, row=0)
    async def increase_five(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.modify_counter(interaction, 5)

    @discord.ui.button(label="⏭️ Increase +10", style=discord.ButtonStyle.success, row=0)
    async def increase_ten(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.modify_counter(interaction, 10)

    # Row 2: -1, -5, -10
    @discord.ui.button(label="◀️ Decrease -1", style=discord.ButtonStyle.danger, row=1)
    async def decrease_one(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.modify_counter(interaction, -1)

    @discord.ui.button(label="⏪ Decrease -5", style=discord.ButtonStyle.danger, row=1)
    async def decrease_five(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.modify_counter(interaction, -5)

    @discord.ui.button(label="⏮️ Decrease -10", style=discord.ButtonStyle.danger, row=1)
    async def decrease_ten(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.modify_counter(interaction, -10)

    # Row 3: Undo, Reset, Finish
    @discord.ui.button(label="↩️ Undo", style=discord.ButtonStyle.primary, row=2)
    async def undo(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self.check_creator(interaction):
            return
        counter = counters[self.message_id]
        # If there's a pre_reset_value, restore to that value (undo reset)
        if "pre_reset_value" in counter and counter["pre_reset_value"] is not None:
            counter["value"] = counter["pre_reset_value"]
            counter["pre_reset_value"] = None
            counter["last_action"] = 0
            save_counters()
            await self.update_message(interaction)
            return
        # Normal undo behavior
        if counter["last_action"] != 0:
            counter["value"] -= counter["last_action"]
            counter["last_action"] = 0
            save_counters()
            await self.update_message(interaction)

    @discord.ui.button(label="🔄 Reset", style=discord.ButtonStyle.primary, row=2)
    async def reset(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self.check_creator(interaction):
            return
        counter = counters[self.message_id]
        counter["pre_reset_value"] = counter["value"]
        counter["value"] = 0
        counter["last_action"] = 0
        counter["finished"] = False
        save_counters()
        await self.update_message(interaction)

    @discord.ui.button(label="⏹️ Finish", style=discord.ButtonStyle.primary, row=2)
    async def finish(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self.check_creator(interaction):
            return
        counter = counters[self.message_id]
        counter["finished"] = not counter["finished"]
        save_counters()
        await self.update_message(interaction)

    async def modify_counter(self, interaction: discord.Interaction, amount: int):
        if not await self.check_creator(interaction):
            return
        counter = counters[self.message_id]
        if counter["finished"]:
            await interaction.response.send_message("This counter is finished!", ephemeral=True)
            return
        counter["value"] += amount
        counter["last_action"] = amount
        save_counters()
        await self.update_message(interaction)

    async def check_creator(self, interaction: discord.Interaction):
        if interaction.user.id != self.creator_id:
            await interaction.response.send_message("Only the creator can use this button!", ephemeral=True)
            return False
        if self.message_id not in counters:
            await interaction.response.send_message("This counter is no longer active!", ephemeral=True)
            return False
        return True

    async def update_message(self, interaction: discord.Interaction):
        counter = counters[self.message_id]
        value = counter["value"]
        finished = counter["finished"]

        # Update button states
        for item in self.children:
            if hasattr(item, "label") and hasattr(item, "disabled"):
                if item.label in ["▶️ Increase +1","⏩ Increase +5","⏭️ Increase +10",
                                  "◀️ Decrease -1","⏪ Decrease -5","⏮️ Decrease -10","↩️ Undo"]:
                    item.disabled = finished
                # Finish and Reset always enabled

        # Display
        display_value = f"{value} ☑️" if finished else str(value)

        embed_color = 0x00FFFF if finished else 0xFFD700
        embed = discord.Embed(
            description=f"**{self.name}: {display_value}**\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
            color=embed_color
        )
        
        # Add capybara image using permanent URL - different image for finished counters
        global capybara_image_url, capybara_finished_url
        if finished and capybara_finished_url:
            embed.set_image(url=capybara_finished_url)
        elif capybara_image_url:
            embed.set_image(url=capybara_image_url)
        
        await interaction.response.edit_message(content="", embed=embed, view=self)

# -------------------------------
# Bot Events
@bot.event
async def on_ready():
    global capybara_image_url, capybara_finished_url
    load_counters()
    
    # Upload both capybara images once to get permanent Discord CDN URLs
    if not capybara_image_url or not capybara_finished_url:
        for guild in bot.guilds:
            for channel in guild.text_channels:
                try:
                    # Upload normal capybara
                    if not capybara_image_url:
                        with open("capybara.png", "rb") as f:
                            file = discord.File(f, filename="capybara.png")
                            img_msg = await channel.send("🦫 Capybot active image", file=file)
                            capybara_image_url = img_msg.attachments[0].url
                    
                    # Upload finished capybara
                    if not capybara_finished_url:
                        with open("capybara_finished.png", "rb") as f:
                            file = discord.File(f, filename="capybara_finished.png")
                            img_msg = await channel.send("🦫 Capybot finished image", file=file)
                            capybara_finished_url = img_msg.attachments[0].url
                    break
                except:
                    continue
            if capybara_image_url and capybara_finished_url:
                break
    
    # Restore views
    for message_id, counter_data in list(counters.items()):
        for guild in bot.guilds:
            for channel in guild.text_channels:
                try:
                    msg = await channel.fetch_message(message_id)
                    if msg:
                        bot.add_view(CounterView(message_id, counter_data["name"], counter_data["creator_id"]), message_id=message_id)
                        break
                except:
                    continue

# -------------------------------
# Listen for messages starting with "!? "
@bot.event
async def on_message(message):
    if message.author == bot.user:
        return
    prefix = "!? "
    if message.content.startswith(prefix):
        content = message.content[len(prefix):].strip()
        parts = content.split()
        if len(parts) >= 2 and parts[-1].isdigit():
            name = " ".join(parts[:-1]).title()
            start_value = int(parts[-1])
        else:
            name = content.title()
            start_value = 0

        if name:
            embed = discord.Embed(
                description=f"**{name}: {start_value}**\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
                color=0xFFD700
            )
            
            # Add capybara image using permanent URL
            global capybara_image_url
            if capybara_image_url:
                embed.set_image(url=capybara_image_url)
            
            # Send message with embed
            msg = await message.channel.send(embed=embed)
            
            # Store counter data
            counters[msg.id] = {
                "name": name,
                "value": start_value,
                "finished": False,
                "creator_id": message.author.id,
                "last_action": 0,
                "pre_reset_value": None
            }
            
            # Update with buttons
            await msg.edit(embed=embed, view=CounterView(msg.id, name, message.author.id))
            save_counters()
    await bot.process_commands(message)

# -------------------------------
# Run the bot
if TOKEN:
    bot.run(TOKEN)